/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projekt.gvidlearn;

import EditorGUI.EditorNovyPanel;
import EditorGUI.EditorStavajiciPanel;
import KurzGUI.KurzyPanel;
import KurzGUI.MainFrame;
import KurzGUI.OtazkaPanel;
import KurzGUI.TemaPanel;
import KurzGUI.Vysledek;
import KurzGUI.VysledekKurzPanel;
import KurzGUI.VysledekTemaPanel;
import Kurz.Kurz;
import Kurz.Tema;
import Vyjimky.Kurz.NacitaniKurzException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import Vyjimky.Tema.NacitaniTemaException;
import java.util.ArrayList;
import java.util.List;
import ZpracovaniSouboru.Soubor;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 *
 * @author Jakub Vávra
 */
public class ProjektGvidlearn {

    // Objekt pro práci se souborem, obsahujím kurz
    private static final Soubor soubor = new Soubor();

    // Načtený kurz
    private static Kurz kurz;

    // Téma, které má uživatel zobrazené
    private static Tema aktualniTema;

    // Kolekce obsahující všechny témata kurzu
    private static List<Tema> temata;

    // Proměnná pro indexování kurzů
    private static int indexTemata;

    // Frame, kde je vykreslený obsah aplikace
    private static final MainFrame frame = new MainFrame();

    // Panel, kde si uživatel vybere kurz. V průběhu běhu aplikace se vyrobí pouze jeden.
    private static KurzyPanel kurzyPanel;

    // Kolekce obsahující panely TemaPanel s tématy 
    private static List<TemaPanel> panelyTemata = null;

    // Kolekce objektů uchovávajících výsledky testů
    private static final List<Vysledek> vysledky = new ArrayList<>();

    // Panel obsahující editor pro nový kurz
    private static final EditorNovyPanel editorNovyPanel = new EditorNovyPanel();
    
    // Panel obsahující editor pro stávající kurzy
    private static final EditorStavajiciPanel editorStavajiciPanel = new EditorStavajiciPanel();
    
    // Logická hodnota, říkající, jestli je přihlášen admin
    private static boolean prihlaseno = false;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frame.setVisible(true);
        aktualizujKurzy();
    }
    
    /**
     * Metoda pro přihlášení pomocí dialogových oken
     */
    public static void prihlaseni() {
        prihlaseno = false;
        
        // Načtení uložených účtů
        Map<String, String> mapa = new HashMap();
        try (BufferedReader rd = new BufferedReader(new FileReader("Ucty.txt"))) {
            String radek;
            while ((radek = rd.readLine()) != null) {
                if(!radek.isBlank()){
                    mapa.put(radek.substring(0, radek.indexOf("|") - 1).trim(), radek.substring(radek.indexOf("|") + 1).trim());
                }
            }
        } catch (IOException e) {
        }
        
        // Příprava dialogového okna
        JTextField jmenoField = new JTextField();
        JPasswordField hesloField = new JPasswordField();

        Object[] zprava = {
            "Uživatelské jméno:", jmenoField,
            "Heslo:", hesloField
        };

        UIManager.put("OptionPane.cancelButtonText", "Zrušit");
        
        // Dokud není přihlášení úspěšné
        boolean uspech = false;
        while (!uspech) {
            int volba = JOptionPane.showConfirmDialog(
                    null,
                    zprava,
                    "Přihlášení",
                    JOptionPane.OK_CANCEL_OPTION
            );

            if (volba == JOptionPane.OK_OPTION) {
                String jmeno = jmenoField.getText();
                char[] poleHeslo = hesloField.getPassword();
                String heslo = Arrays.toString(poleHeslo).replace("[", "").replace("]", "").replace(", ", "");
                
                // KOntrola zadaných údajů
                if (mapa.containsKey(jmeno)) {
                    if (mapa.get(jmeno).equals(heslo)) {
                        JOptionPane.showMessageDialog(null, "Admin přihlášen.", "Úspěch!", JOptionPane.INFORMATION_MESSAGE);
                        prihlaseno = true;
                        uspech = true;
                    } else {
                        JOptionPane.showMessageDialog(null, "Špatné heslo!", "Error!", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Uživatel nenalezen!", "Error!", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                uspech = true;
            }
        }
        aktualizujKurzy();
    }
    
    /**
     * Metoda pro vytvoření nového admin účtu
     */
    public static void vytvoritUcet() {
        // Načtení uložených účtů
        Map<String, String> mapa = new HashMap();
        try (BufferedReader rd = new BufferedReader(new FileReader("Ucty.txt"))) {
            String radek;
            while ((radek = rd.readLine()) != null) {
                if(!radek.isBlank()){
                    mapa.put(radek.substring(0, radek.indexOf("|") - 1).trim(), radek.substring(radek.indexOf("|") + 1).trim());
                }
            }
        } catch (IOException e) {
        }
        
        // Příprava dialogového okna
        JTextField jmenoField = new JTextField();
        JTextField hesloField = new JTextField();

        Object[] zprava = {
            "Uživatelské jméno:", jmenoField,
            "Heslo:", hesloField
        };

        UIManager.put("OptionPane.cancelButtonText", "Zrušit");
        
        // Dokud nejsou zadány platné údaje
        boolean uspech = false;
        while (!uspech) {
            int volba = JOptionPane.showConfirmDialog(
                    null,
                    zprava,
                    "Nový uživatel",
                    JOptionPane.OK_CANCEL_OPTION
            );

            if (volba == JOptionPane.OK_OPTION) {
                String jmeno = jmenoField.getText();
                String heslo = hesloField.getText();
                
                // KOntrola duplicity účtů
                if (mapa.containsKey(jmeno)) {
                    JOptionPane.showMessageDialog(null, "Uživatel s tímto jménem již existuje!", "Error!", JOptionPane.ERROR_MESSAGE);
                } else {
                    mapa.put(jmeno, heslo);
                    JOptionPane.showMessageDialog(null, "Účet vytvořen.", "Úspěch!", JOptionPane.INFORMATION_MESSAGE);
                    try (FileWriter wr = new FileWriter("Ucty.txt", false)) {
                        for (Map.Entry<String, String> zaznam : mapa.entrySet()) {
                            wr.write("\n" + zaznam.getKey() + " | " + zaznam.getValue());
                        }
                    } catch (IOException e) {
                    }
                    uspech = true;
                    prihlaseno = true;
                }

            } else {
                uspech = true;
            }
        }
        
        aktualizujKurzy();
    }
    
    /**
     * Metoda pro přejmenování kurzu
     * @param puvodni je původní název
     * @param novy je nový název
     */
    public static void prejmenovat(String puvodni, String novy) {
        // KOntrola, že název neobsahuje mezery
        if (novy.trim().contains(" ")) {
            JOptionPane.showMessageDialog(null, "Název kurzu nesmí obsahovat mezery!", "Error!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Načtení seznamu kurzů
        String[] pole;
        try {
            DefaultListModel nazvy = soubor.nactiSeznamKurzu();
            pole = new String[nazvy.size()];
            for (int i = 0; i < nazvy.size(); i++) {
                pole[i] = (String) nazvy.getElementAt(i);
            }
        } catch (IOException e) {
            return;
        }
        
        // Kontrola duplicity
        if (Arrays.asList(pole).contains(novy)) {
            JOptionPane.showMessageDialog(null, "Kurz s takovým názvem již existuje!", "Error!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Přejmenování v souboru s kurzem
        try {
            String obsahSouboru = new String(Files.readAllBytes(Paths.get(soubor.getCesta(puvodni))));
            String novyObsah = obsahSouboru.replaceAll(puvodni, novy);
            Files.write(Paths.get(soubor.getCesta(puvodni)), novyObsah.getBytes());
        } catch (IOException ex) {
        }
        
        // Zápis nového názvu do souboru s kurzy
        try {
            String obsahSouboru = new String(Files.readAllBytes(Paths.get("Kurzy.txt")));
            String novyObsah = obsahSouboru.replaceAll("\\b" + Pattern.quote(puvodni) + "\\b", novy);
            Files.write(Paths.get("Kurzy.txt"), novyObsah.getBytes());
        } catch (IOException ex) {
        }
        
        // Přejmenování v kolekci souborů
        String stary = soubor.getCesta(puvodni);
        soubor.vymena(puvodni, novy);
        
        // Přejmenování souboru s kurzem
        try {
            Files.move(Paths.get(stary), Paths.get(novy + ".txt"), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
        }

        aktualizujKurzy();
        JOptionPane.showMessageDialog(null, "Úspěch!", "Kurz přejmenován.", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Metoda pro odstranění kurzu
     * @param nazev je název kurzu
     */
    public static void smazat(String nazev) {
        // Odstranění souboru s kurzem
        File file = new File(soubor.getCesta(nazev));
        file.delete();
        
        // Smazání ze souboru s kurzy
        StringBuilder novy = new StringBuilder();
        try (BufferedReader rd = new BufferedReader(new FileReader("Kurzy.txt"))) {
            String radek;
            while ((radek = rd.readLine()) != null) {
                if (!radek.trim().equals(nazev + ".txt" + " | " + nazev)) {
                    novy.append(radek).append("\n");
                }
            }
        } catch (IOException e) {
        }

        try {
            Files.write(Paths.get("Kurzy.txt"), novy.toString().getBytes());
        } catch (IOException ex) {
        }
        soubor.smazat(nazev);

        aktualizujKurzy();
        JOptionPane.showMessageDialog(null, "Úspěch!", "Kurz smazán.", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Metoda pro spuštění editoru
     * @param nazev je název souboru k úpravě
     */
    public static void spustEditor(String nazev) {
        editorStavajiciPanel.vynuluj();
        zmenPanel(new EditorStavajiciPanel(nazev));
    }

    /**
     * Metoda pro spuštění editoru - používá ji tlačítko editorButton ve třídě
     * KurzyPanel
     */
    public static void vytvorNovyKurz() {
        editorNovyPanel.vynuluj();
        zmenPanel(editorNovyPanel);
    }

    /**
     * Metoda pro změnu panelu ve framu
     *
     * @param panel je nový panel k zobrazení
     */
    private static void zmenPanel(JPanel panel) {
        frame.getContentPane().removeAll(); // Odstranění starého panelu
        frame.add(panel); // Vložení nového panelu
        frame.validate(); // Vykreslení změn
        frame.repaint();
    }

    /**
     * Metoda pro aktualizování seznamu kurzů
     */
    public static void aktualizujKurzy() {
        try {
            kurzyPanel = new KurzyPanel(soubor.nactiSeznamKurzu()); // Načtení seznamu dostupných kurzů
            if(prihlaseno){
                kurzyPanel.adminTlacitka();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Nepodařilo se načíst kurzy! Zkontrolujte soubor Kurzy.txt", "Error!", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        zobrazKurzy();
    }

    /**
     * Metoda pro zobrazení nabídky kurzů - používají ji tlačítka zpetButton ve
     * třídách TemaPanel, VysledekKurzPanel a EditorNovyPanel
     */
    public static void zobrazKurzy() {
        zmenPanel(kurzyPanel);
    }

    /**
     * Metoda načte obsah vybraného kurzu - používáji tlačítko spustitButton ve
     * třídě KurzyPanel
     *
     * @param nazev je název vybraného kurzu
     */
    public static void nactiVybranyKurz(String nazev) {
        try {
            indexTemata = 0;
            kurz = soubor.nactiKurz(nazev); // načtení kurzu
            temata = kurz.getTemata(); // uložení témat

            panelyTemata = new ArrayList<>();

            for (Tema tema : temata) { // vytvoření panelů TemaPanel pro každé téma
                TemaPanel panel = new TemaPanel(tema.getNazev(), tema.getInformace().replace("\n", " "), temata.indexOf(tema) + 1);
                panelyTemata.add(panel);
            }

            zobrazTema(); // zobrazení prvního tématu
        } catch (NacitaniKurzException | NacitaniTemaException | NacitaniOtazkaException e) {
            JOptionPane.showMessageDialog(null, "Při načítání obsahu kurzu došlo k následující chybě: \n" + e.toString() + "\nPříčinou je:\n" + e.getCause(), "Error!", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    /**
     * Metoda pro zobrazení dalšího tématu v pořadí - používá ji tlačítko
     * daleButton ve třídě VysledekTemaPanel
     */
    public static void zobrazTema() {
        if (indexTemata == temata.size()) { // Pokud již není další téma, zobrazí se výsledky kurzu
            zmenPanel(new VysledekKurzPanel(kurz.getNazev(), vysledky));
        } else {
            zmenPanel(panelyTemata.get(indexTemata));
            aktualniTema = temata.get(indexTemata);
            indexTemata += 1; // Posun indexu
        }
    }

    /**
     * Metoda pro zobrazení tématu, které se vztahuje k aktuálně spuštěný
     * otázkám - používají ji tlačítka zpetButton ve třídách OtazkaPanel a
     * VysledekTemaPanel
     */
    public static void zobrazAktualniTema() {
        indexTemata -= 1; // Posunutí idexu zpět
        zobrazTema();
    }

    /**
     * Metoda pro zobrazení otázek aktuálního tématu - používá ji tlačítko
     * testButton ve třídě TemaPanel
     */
    public static void zobrazOtazky() {
        zmenPanel(new OtazkaPanel(aktualniTema.getOtazky()));
    }

    /**
     * Metoda pro zobrazení výsledků pro aktuální téma - používá ji tlačítko
     * zkontrolovatButton ve třídách DoplnovackaPanel, PravdaLezPanel a
     * TextPanel
     */
    public static void zobrazVysledky() {
        VysledekTemaPanel aktualniVysledekTema = new VysledekTemaPanel(indexTemata, aktualniTema.getNazev());
        zmenPanel(aktualniVysledekTema);
        vysledky.add(aktualniVysledekTema.getVysledek()); // Přidání výsledků do kolekce se všemi výsledky
    }

}
