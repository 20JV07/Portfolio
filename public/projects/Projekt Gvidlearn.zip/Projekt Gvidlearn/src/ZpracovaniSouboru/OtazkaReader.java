/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru;

import ZpracovaniSouboru.Tovarna.DoplnovackaFactoryReader;
import ZpracovaniSouboru.Tovarna.TextFactoryReader;
import Kurz.Otazka;
import Vyjimky.Otazka.NacitaniOtazkaException;
import static ZpracovaniSouboru.Tovarna.OtazkaFactory.create;
import ZpracovaniSouboru.Tovarna.PravdaLezFactoryReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static ZpracovaniSouboru.Tovarna.OtazkaFactory.registerOtazkaReader;

/**
 * Třída pro načtení všech typů otázek
 * @author Jakub Vávra
 */
public class OtazkaReader {
    // Čtenář
    private final BufferedReader rd;
    private final List<String> typyOtazek = new ArrayList<>(Arrays.asList("Text", "Doplňovačka", "PravdaLež"));
    
    /**
     * Konstruktor
     * @param rd je otevřený čtenář
     */
    public OtazkaReader(BufferedReader rd){
        this.rd = rd;
        registrujOtazky();
    }   
    
    /**
     * Metoda, která zjistí, jestli je možné načíst otázku
     * @return logickou hodnotu
     * @throws IOException 
     */
    public boolean hasNextOtazka() throws IOException{
        rd.mark(1000); // Řádek s klíčovým slovem musí být načten vícekrát
        String radek = rd.readLine();
        
        while(radek != null){
            if(radek.contains(":")){ // Pokud řádek obsahuje klíčové slovo
                if(typyOtazek.contains(radek.substring(0, radek.indexOf(":")))){ // Pokud je klíčové slovo typ otázky
                    rd.reset();
                    return true;
                }
                else if(radek.startsWith("Téma:") || radek.startsWith("Test:")){ // Pokud je klíčové slovo TÉMA nebo TEST
                    rd.reset();
                    return false;
                }
            }
            
            rd.mark(1000);
            radek = rd.readLine();
        }
        
        return false;
    }
    
    /**
     * Metoda pro registraci obsahu továrny
     */
    private void registrujOtazky(){
        registerOtazkaReader("Text", new TextFactoryReader(rd));
        registerOtazkaReader("Doplňovačka", new DoplnovackaFactoryReader(rd));
        registerOtazkaReader("PravdaLež", new PravdaLezFactoryReader(rd));
    }
    
    /**
     * Metoda pro načtení otázky
     * @return načtenou otázku, nebo null při neúspěchu
     * @throws IOException 
     * @throws Vyjimky.Otazka.NacitaniOtazkaException 
     */
    public Otazka nactiOtazku() throws IOException, NacitaniOtazkaException {
        String radek;
        
        // Načítání ze souboru
        while((radek = rd.readLine()) != null){
            try{
                if(radek.contains(":")){
                    return create(radek);
                }
            }catch(NacitaniOtazkaException e){
                throw e;
            }
        }
        return null;
    }

}