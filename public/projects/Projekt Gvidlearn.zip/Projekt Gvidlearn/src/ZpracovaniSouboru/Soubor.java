/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru;

import Kurz.Kurz;
import Vyjimky.Kurz.NacitaniKurzException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import Vyjimky.Tema.NacitaniTemaException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultListModel;

/**
 * Třída pro zpracování souboru v daném formátu
 * @author Jakub Vávra
 */
public class Soubor {
    
    // Kolekce pro ukládání dvojic název kurzu a cesty ke kurzu
    protected Map<String, String> mapa = new HashMap();
    
    /**
     * Konstruktor
     */
    public Soubor(){
    }
    
    /**
     * Metoda pro načtení seznamu dostupných kurzů
     * @return ListModel se seznamem kurzů
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public DefaultListModel nactiSeznamKurzu() throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader("Kurzy.txt"));
        
        DefaultListModel nazvy = new DefaultListModel<>();
        
        String radek;
        int index = 0;
        while((radek = br.readLine()) !=  null){
            if(!radek.isBlank()){
                nazvy.addElement(radek.substring(radek.indexOf("|")+1).trim()); // VLožení názvu do ListModelu
                mapa.put((String) nazvy.getElementAt(index), radek.substring(0, radek.indexOf("|")).trim()); // Vložení do kolekce
                index++;
            }
        }
        
        return nazvy;       
    }
    
    /**
     * Metoda pro zpracování obsahu souboru
     * @param nazev
     * @return načtený kurz, nebo vyjimku při neúspěchu
     * @throws Vyjimky.Kurz.NacitaniKurzException
     * @throws Vyjimky.Tema.NacitaniTemaException
     * @throws Vyjimky.Otazka.NacitaniOtazkaException
     */
    public Kurz nactiKurz(String nazev) throws NacitaniKurzException, NacitaniTemaException, NacitaniOtazkaException{
        Kurz kurz = null;
        try(BufferedReader rd = new BufferedReader(new FileReader(mapa.get(nazev)))){
            KurzReader kr = new KurzReader(rd); // Kurz má vlastní třídu pro načítání
            kurz = kr.nactiKurz();
        }
        catch(IOException e){
            System.out.println("Zadaný soubor neexistuje nebo ho nelze zpracovat.");
        }
        catch(NacitaniKurzException e){ // Zachycení chyb
            throw e;
        }
        
        return kurz;
    }
    
    /**
     * Getter pro cestu k souboru
     * @param nazev je název kurzu
     * @return cesta k souboru
     */
    public String getCesta(String nazev){
        return mapa.get(nazev);
    }
    
    /**
     * Metoda pro přejmenování souboru v kolekci
     * @param puvodni je puvodni název
     * @param novy je nový název
     */
    public void vymena(String puvodni, String novy){
        mapa.remove(puvodni);
        mapa.put(novy, novy + ".txt");
    }
    
    /**
     * Metoda pro odstranění souboru z kolekce
     * @param klic je název souboru
     */
    public void smazat(String klic){
        mapa.remove(klic);
    }
}
