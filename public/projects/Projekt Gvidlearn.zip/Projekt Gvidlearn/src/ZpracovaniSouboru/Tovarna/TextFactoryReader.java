/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru.Tovarna;

import Kurz.Otazka;
import Kurz.Text;
import Vyjimky.Otazka.ChybneBodyException;
import Vyjimky.Otazka.ChybneSpravneOdpovediException;
import Vyjimky.Otazka.ChybneZadaniException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Třída pro načítání otázky typu TEXT
 * @author Jakub Vávra
 */
public class TextFactoryReader extends OtazkaFactoryReader {
    // Čtenář
    private final BufferedReader rd;
    
    /**
     * Konstruktor
     * @param rd je otevřený čtenář
     */
    public TextFactoryReader(BufferedReader rd){
        this.rd = rd;
    }
    
    /**
     * Překrytá metoda pro načtení otázky typu TEXT
     * @param prvniRadek je již načtený řádek
     * @return načtenou otázku, nebo vyjimku při neúspěchu
     * @throws IOException
     * @throws NacitaniOtazkaException 
     */
    @Override
    public Otazka vytvorOtazku(String prvniRadek) throws IOException, NacitaniOtazkaException{
        try{
            if(prvniRadek.trim().equals("Text:")){ // Pokud v souboru není zadání
                throw new ChybneZadaniException();     
            }

            StringBuilder zadani = new StringBuilder();
            zadani.append(prvniRadek.substring(5)).append("\n");

            String radek;
            int body = 0;

            // Proměnné pro kontrolu načtení všech atributů otázky
            boolean bodyOk = false;
            boolean spravneOk = false;

            rd.mark(1000);

            // Načtení zadání a počtu bodů
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("Body:")){
                    body = Integer.parseInt(radek.substring(5)); // Převod na číslo
                    bodyOk = true;
                    break;
                }
                else if(klicSlovaOtazka.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    throw new ChybneZadaniException();
                }
                else if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    rd.reset();
                    throw new ChybneZadaniException();
                }
                else if(!radek.trim().isEmpty() && !radek.startsWith("#")){
                    zadani.append(radek).append("\n"); // Přídání části zadání
                }
                rd.mark(1000);
            }

            if(!bodyOk){
                throw new ChybneBodyException();
            }

            // Načtení správných odpovědí
            List<String> spravneOdpovedi = new ArrayList<>();
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("OK:")){
                    radek = radek.substring(3);
                    String[] slova = radek.split(",");
                    for(String slovo: slova){
                        spravneOdpovedi.add(slovo.trim()); // Přídání správných odpovědí
                    }
                    if(spravneOdpovedi.isEmpty()){
                        throw new ChybneSpravneOdpovediException();
                    }
                    spravneOk = true;
                    break;
                }
                else if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    rd.reset();
                    throw new ChybneSpravneOdpovediException();
                }
                rd.mark(1000);
            }
            if(bodyOk && spravneOk){ // Pokud byly načteny všechny atributy
                return new Text(zadani.toString(), spravneOdpovedi, body);
            }
            return null; // Nebyly načteny všechny atributy
        }catch(ChybneZadaniException | ChybneSpravneOdpovediException | ChybneBodyException e){ // Zachycení chyb
            throw new NacitaniOtazkaException("Při načítání otázky typu TEXT došlo k chybě.", e);
        }
    }
    
}
