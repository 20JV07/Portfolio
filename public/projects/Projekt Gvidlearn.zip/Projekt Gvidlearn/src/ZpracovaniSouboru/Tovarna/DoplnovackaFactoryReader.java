/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru.Tovarna;

import Kurz.Doplnovacka;
import Kurz.Otazka;
import Vyjimky.Otazka.ChybneBodyException;
import Vyjimky.Otazka.ChybneSpatneOdpovediException;
import Vyjimky.Otazka.ChybneSpravneOdpovediException;
import Vyjimky.Otazka.ChybneZadaniException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Třída pro načítání otázky typu DOPLŇOVAČKA
 * @author Jakub Vávra
 */
public class DoplnovackaFactoryReader extends OtazkaFactoryReader {
    // Čtenář
    private final BufferedReader rd;
    
    /**
     * Konstruktor
     * @param rd je již otevřený čtenář
     */
    public DoplnovackaFactoryReader(BufferedReader rd){
        this.rd = rd;
        klicSlovaOtazka.add("KO:"); // Nové klíčové slovo otázky
    }
    
    /**
     * Překrytá metoda pro načtení otázky typu DOPLŇOVAČKA
     * @param prvniRadek je již načtený řádek
     * @return načtenou otázku, nebo vyjimku při neúspěchu
     * @throws IOException
     * @throws NacitaniOtazkaException 
     */
    @Override
    public Otazka vytvorOtazku(String prvniRadek) throws IOException, NacitaniOtazkaException {
        try{
            if(prvniRadek.trim().equals("Doplňovačka:")){ // Pokud v souboru není zadání
                throw new ChybneZadaniException();
            }

            StringBuilder zadani = new StringBuilder();
            zadani.append(prvniRadek.substring(12)).append("\n");

            String radek;
            int body = 0;

            // Proměnné pro kontrolu načtení všech atributů otázky
            boolean bodyOk = false;
            boolean spravneOk = false;
            boolean spatneOk = false;

            rd.mark(1000);

            // Načtení zadání a počtu bodů
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("Body:")){
                    String radekBody = radek.substring(5);
                    if(!radekBody.isEmpty()){
                        body = Integer.parseInt(radekBody); // Převod na číslo
                        bodyOk = true;
                    }
                    break;
                }
                else if(klicSlovaOtazka.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    throw new ChybneZadaniException();
                }
                else if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    rd.reset();
                    throw new ChybneZadaniException();
                }
                else if(!radek.trim().isEmpty() && !radek.startsWith("#")){
                    zadani.append(radek).append("\n"); // Přídání části zadání
                }
                rd.mark(1000);
            }

            if(!bodyOk){
                throw new ChybneBodyException();
            }

            List<String> spravneOdpovedi = new ArrayList<>();
            List<String> spatneOdpovedi = new ArrayList<>();

            rd.mark(1000);

            // Načtení správných a chybných odpovědí
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("OK:")){
                    radek = radek.substring(3);
                    String[] slova = radek.split(",");
                    for(String slovo: slova){
                        spravneOdpovedi.add(slovo.trim()); // Přídání správných odpovědí
                    }
                    if(spravneOdpovedi.isEmpty()){
                        throw new ChybneSpravneOdpovediException();
                    }
                    spravneOk = true;
                    rd.mark(1000);
                }
                else if(radek.startsWith("KO:")){
                    if(!spravneOk){
                        throw new ChybneSpravneOdpovediException();
                    }
                    radek = radek.substring(3);
                    String[] slova = radek.split(",");
                    for(String slovo: slova){
                        spatneOdpovedi.add(slovo.trim()); // Přídání chybných odpovědí
                    }
                    if(spatneOdpovedi.isEmpty()){
                        throw new ChybneSpatneOdpovediException();
                    }
                    spatneOk = true;
                    break;
                }
                else if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    rd.reset();
                    if(spravneOk && !spatneOk){
                        throw new ChybneSpatneOdpovediException();
                    }
                    else{
                        throw new ChybneSpravneOdpovediException();
                    }
                }
                rd.mark(1000);
            }
            if(bodyOk && spravneOk && spatneOk){ // Pokud byly načteny všechny atributy
                return new Doplnovacka(zadani.toString(), spravneOdpovedi, spatneOdpovedi, body);
            }
            return null; // Nebyly načteny všechny atributy
        }catch(ChybneZadaniException | ChybneSpravneOdpovediException | ChybneSpatneOdpovediException | ChybneBodyException e){ // Zachycení chyb
            throw new NacitaniOtazkaException("Při načítání otázky typu DOPLŇOVAČKA došlo k chybě.", e);
        }
    }
    
}
