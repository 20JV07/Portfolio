/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ZpracovaniSouboru.Tovarna;

import Kurz.Otazka;
import Vyjimky.Otazka.NacitaniOtazkaException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Abstraktní třída, která je předkem všech tříd pro načítání otázek.
 * @author Jakub Vávra
 */
public abstract class OtazkaFactoryReader {
    // Klíčová slova souboru
    public List<String> klicSlovaSoubor = new ArrayList<>(Arrays.asList("Kurz:", "Téma:", "Test:", "Text:", "Doplňovačka:", "PravdaLež:"));
    
    // Klíčová slova souboru
    protected List<String> klicSlovaOtazka = new ArrayList<>(Arrays.asList("Body:", "OK:"));
    
    /**
     * Metoda pro načtení otázky.
     * @param prvniRadek je již načtený řádek s typem otázky
     * @return načtenou otázku, nebo vyjimku při neúspěchu
     * @throws IOException
     * @throws NacitaniOtazkaException 
     */
    public abstract Otazka vytvorOtazku(String prvniRadek) throws IOException, NacitaniOtazkaException;
}
