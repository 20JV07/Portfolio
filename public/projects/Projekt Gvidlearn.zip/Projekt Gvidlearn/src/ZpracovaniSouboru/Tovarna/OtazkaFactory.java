/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru.Tovarna;

import Kurz.Otazka;
import Vyjimky.Otazka.NacitaniOtazkaException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Tovární třída pro obsluhu načítání otázek.
 * @author Jakub Vávra
 */
public class OtazkaFactory {
    // Kolekce pro ukládání dvojic hodnot <typ otázky> a <odpovídající třída pro načítání>
    private static final Map<String, OtazkaFactoryReader> mapa = new HashMap<>();
    
    /**
     * Metoda pro uložení dvojice hodnot do kolekce
     * @param typOtazky je typ otázky
     * @param otazkaCreator je objekt pro načítání
     */
    public static void registerOtazkaReader(String typOtazky, OtazkaFactoryReader otazkaCreator){
        mapa.put(typOtazky, otazkaCreator);
    }
    
    /**
     * Metoda pro výběr odpovídajícího objektu pro načítání otázek a vytvoření otázky
     * @param prvniRadek je již načtený řádek
     * @return načtenou otázku
     * @throws IOException
     * @throws NacitaniOtazkaException 
     */
    public static Otazka create(String prvniRadek) throws IOException, NacitaniOtazkaException{
        OtazkaFactoryReader otazkaFR = mapa.get(prvniRadek.substring(0, prvniRadek.indexOf(":")));
        
        if(otazkaFR == null){ // Pokud nebyla v kolekci nalezena odpovídající hodnota
            return null;
        }
        
        return otazkaFR.vytvorOtazku(prvniRadek);
    }
}
