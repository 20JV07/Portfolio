/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru.Tovarna;

import Kurz.Otazka;
import Kurz.PravdaLez;
import Vyjimky.Otazka.ChybneBodyException;
import Vyjimky.Otazka.ChybneSpravneOdpovediException;
import Vyjimky.Otazka.ChybneTvrzeniException;
import Vyjimky.Otazka.ChybneZadaniException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Třída pro načítání otázky typu PRAVDA/LEŽ
 * @author Jakub Vávra
 */
public class PravdaLezFactoryReader extends OtazkaFactoryReader {
    // Čtenář
    private final BufferedReader rd;

    /**
     * Konstruktor
     * @param rd je již otevřený čtenář
     */
    public PravdaLezFactoryReader(BufferedReader rd) {
        this.rd = rd;
        klicSlovaOtazka.add("Tvrzení:"); // Nové klíčové slovo otázky
    }
    
    /**
     * Překrytá metoda pro načtení otázky typu PRAVDA/LEŽ
     * @param prvniRadek je již načtený řádek
     * @return načtenou otázku, nebo vyjimku při neúspěchu
     * @throws IOException
     * @throws NacitaniOtazkaException 
     */
    @Override
    public Otazka vytvorOtazku(String prvniRadek) throws IOException, NacitaniOtazkaException {
        try{
            if(prvniRadek.trim().equals("PravdaLež:")){ // Pokud v souboru není zadání
                throw new ChybneZadaniException();  
            }

            StringBuilder zadani = new StringBuilder();
            zadani.append(prvniRadek.substring(10)).append("\n");

            String radek;
            StringBuilder spravneTvrzeni = new StringBuilder();
            int body = 0;

            // Proměnné pro kontrolu načtení všech atributů otázky
            boolean bodyOk = false;
            boolean spravneOk = false;
            boolean tvrzeniOk = false;

            rd.mark(1000);
            
            // Načtení zadání a počtu bodů
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("Body:")){
                    body = Integer.parseInt(radek.substring(5)); // Převod na číslo
                    bodyOk = true;
                    break;
                }
                else if(klicSlovaOtazka.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    throw new ChybneZadaniException();
                }
                else if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    rd.reset();
                    throw new ChybneZadaniException();
                }
                else if(!radek.trim().isEmpty() && !radek.startsWith("#")){
                    zadani.append(radek).append("\n"); // Přídání části zadání
                    rd.mark(1000);
                }
                rd.mark(1000);
            }
            
            if(!bodyOk){
                throw new ChybneBodyException();
            }
            
            // Načtení správných odpovědí
            List<String> spravneOdpovedi = new ArrayList<>();
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("OK:")){
                    spravneOdpovedi.add(radek.substring(3));
                    if(spravneOdpovedi.isEmpty()){
                        throw new ChybneSpravneOdpovediException();
                    }
                    spravneOk = true;
                }
                // Načtení správného výroku
                else if(radek.startsWith("Tvrzení:")){
                    spravneTvrzeni.append(radek.substring(8));
                    tvrzeniOk = true;
                    
                    rd.mark(1000);
                    while((radek = rd.readLine()) != null){
                        if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){
                            rd.reset();
                            break;
                        }
                        else if(!radek.trim().isEmpty() && !radek.startsWith("#")){
                            spravneTvrzeni.append("\n").append(radek); // Přídání části správného výroku
                        }
                        rd.mark(1000);
                    }
                    break;
                }
                else if(klicSlovaSoubor.contains(radek.substring(0, radek.indexOf(":") + 1))){ // Když je otázka ve špatném formátu
                    rd.reset();
                    if(spravneOk){
                        throw new ChybneTvrzeniException();
                    }
                    else{
                        throw new ChybneSpravneOdpovediException();
                    }
                }
                rd.mark(1000);
            }
            if(bodyOk && spravneOk && tvrzeniOk){ // Pokud byly načteny všechny atributy
                return new PravdaLez(zadani.toString(), spravneOdpovedi, spravneTvrzeni.toString(), body);
            }
            return null; // Nebyly načteny všechny atributy
        }catch(ChybneZadaniException | ChybneSpravneOdpovediException | ChybneBodyException | ChybneTvrzeniException e){ // Zachycení chyb
            throw new NacitaniOtazkaException("Při načítání otázky typu PRAVDA/LEŽ došlo k chybě.", e);
        }
    }
    
}
