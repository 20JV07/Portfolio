/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru;

import Kurz.Kurz;
import Vyjimky.Kurz.ChybnyNazevKurzuException;
import Vyjimky.Kurz.KurzNenalezenException;
import Vyjimky.Kurz.NacitaniKurzException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import Vyjimky.Tema.NacitaniTemaException;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Třída pro načtení kurzu
 * @author Jakub Vávra
 */
public class KurzReader {
    // Čtenář
    private final BufferedReader rd;
    
    /**
     * Konstruktor
     * @param rd je otevřený čtenář
     */
    public KurzReader(BufferedReader rd){
        this.rd = rd;
    }
    
    /**
     * Metoda pro načtení kurzu
     * @return načtený kurz, nebo vyjimku při neúspěchu
     * @throws IOException 
     * @throws Vyjimky.Kurz.NacitaniKurzException 
     * @throws Vyjimky.Tema.NacitaniTemaException 
     * @throws Vyjimky.Otazka.NacitaniOtazkaException 
     */
    public Kurz nactiKurz() throws IOException, NacitaniKurzException, NacitaniTemaException, NacitaniOtazkaException {
        String radek;
        
        try{
            // Dokud program nenarazí na řádek s klíčovým slovem
            while((radek = rd.readLine()) != null){
                if(radek.startsWith("Kurz:")){
                    break;
                }
                throw new KurzNenalezenException();
            }

            if(radek.trim().equals("Kurz:")){ // Pokud kurz nemá název
                throw new ChybnyNazevKurzuException();
            }
        }catch(ChybnyNazevKurzuException | KurzNenalezenException e){ // Zachycení chyb
            throw new NacitaniKurzException("Při načítání kurzu došlo k chybě.", e);
        }
        
        // Vytvoření nového kurzu
        Kurz kurz =  new Kurz(radek.substring(5).trim());
        
        TemaReader tr = new TemaReader(rd); // Téma má vlastní třídu pro načítání
        
        // Načítání témat
        try{
            while(tr.hasNextTema()){
                kurz.pridatTema(tr.nactiTema());
            }
        }catch(NacitaniTemaException e){
            throw e;
        }
        
        if(kurz.getTemata().isEmpty()){
            throw new NacitaniKurzException("Nenalezeny žádná témata!");
        }
        
        return kurz;
    }
}
