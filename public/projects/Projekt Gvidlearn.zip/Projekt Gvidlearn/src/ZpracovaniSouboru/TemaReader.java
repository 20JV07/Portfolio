/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZpracovaniSouboru;

import Kurz.Tema;
import Vyjimky.Otazka.NacitaniOtazkaException;
import Vyjimky.Tema.ChybneInformaceException;
import Vyjimky.Tema.ChybnyNazevTematuException;
import Vyjimky.Tema.NacitaniTemaException;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Třída pro načtení tématu
 * @author Jakub Vávra
 */
public class TemaReader {
    // Čtenář
    private final BufferedReader rd;
    
    /**
     * Konstruktor
     * @param rd je otevřený čtenář
     */
    public TemaReader(BufferedReader rd){
        this.rd = rd;
    }
    
    /**
     * Metoda, která zjistí, jestli je možné načíst téma
     * @return logickou hodnotu
     * @throws IOException 
     * @throws Vyjimky.Tema.NacitaniTemaException 
     */
    public boolean hasNextTema() throws IOException, NacitaniTemaException{
        rd.mark(1000); // Řádek s klíčovým slovem TÉMA musí být načten vícekrát
        String radek = rd.readLine();
     
        while(radek != null){
            if(radek.startsWith("Téma:")){
                rd.reset();
                return true;
            }
            if(radek.startsWith("Text:") | radek.startsWith("Doplňovačka:") | radek.startsWith("PravdaLež:")){
                throw new NacitaniTemaException("Nalezena sada otázek bez tématu!");
            }
            
            rd.mark(1000);
            radek = rd.readLine();
        }
        
        return false;
    }
      
    /**
     * Metoda pro načtení tématu
     * @return načtené téma, nebo vyjimku nebo null při neúspěchu 
     * @throws IOException 
     * @throws Vyjimky.Tema.NacitaniTemaException 
     * @throws Vyjimky.Otazka.NacitaniOtazkaException 
     */
    public Tema nactiTema() throws IOException, NacitaniTemaException, NacitaniOtazkaException {
        String radek;
        
        // Dokud program nenarazí na řádek s klíčovým slovem
        while((radek = rd.readLine()) != null){
            try{
                if(radek.startsWith("Téma:")){
                    if(radek.trim().equals("Téma:")){ // Pokud téma nemá název
                        throw new ChybnyNazevTematuException();
                    }
                    return _nactiTema(radek.substring(5).trim()); // Volání pomocné metody
                }
            }catch(ChybnyNazevTematuException | ChybneInformaceException e){ // Zachycení chyb
                throw new NacitaniTemaException("Pří načítání tématu došlo k chybě.", e);
            }catch(NacitaniOtazkaException e){
                throw e;
            }
        }
        return null;
    }
    
    /**
     * Pomocná metoda pro načtení tématu 
     * @param nazev je název tématu
     * @return načtené téma, nebo vyjimku při neúspěchu
     * @throws IOException
     */
    private Tema _nactiTema(String nazev) throws IOException, ChybneInformaceException, NacitaniOtazkaException, NacitaniTemaException{
        // Vytvoření nového tématu
        Tema tema = new Tema(nazev);
        
        StringBuilder informace = new StringBuilder();
        String radek;
        
        // Proměnná pro kontrolu načtení informací o tématu
        boolean informaceOk = false;
        
        // Načítání informací o tématu, dokud program nenačte klíčové slovo
        while((radek = rd.readLine()) != null){
            if(radek.startsWith("Test:")){
                break;
            }
            else if(!radek.isEmpty() && !radek.startsWith("#")){
                informace.append(radek).append("\n");
                informaceOk = true;
            }
        }
        
        if(!informaceOk){ // Pokud nejsou informace o tématu
            throw new ChybneInformaceException();
        }
        
        // Přidání informací
        tema.pridatInformace(informace.toString());
        
        OtazkaReader or = new OtazkaReader(rd); // Otázka má vlastní třídu pro načítání
        
        // Načítání otázek
        try{
            while(or.hasNextOtazka()){
                tema.pridatOtazku(or.nactiOtazku());
            } 
        }catch(NacitaniOtazkaException e){
            throw e;
        }
        
        if(tema.getOtazky().isEmpty()){
            throw new NacitaniTemaException("Nalezeno téma bez otázek!");
        }
        
        return tema;
    }
}
