/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Kurz;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Abstraktní třída, která je předkem všech typů otázek.
 * @author Jakub Vávra
 */
public abstract class Otazka {
    // Zadání otázky
    protected String zadani;
    
    // Kolekce obsahující správné odpovědi
    protected List<String> spravneOdpovedi = new ArrayList<>();
    
    // Kolekce obsahující odpovědi zadané uživatelem
    protected List<String> odpovedi = new ArrayList<>();
    
    // Počet bodů za otázku
    protected int body;
    
    // Logická hodnota, která říká, jestli byla otázka správně zodpovězena
    protected boolean jeSpravne = false;
    
    // Klíčová slova souboru
    protected List<String> klicSlovaSoubor = new ArrayList<>(Arrays.asList("Kurz:", "Téma:", "Test:", "Text:", "Doplňovačka:", "PravdaLež:"));
    
    // Klíčová slova otázky
    protected List<String> klicSlovaOtazka = new ArrayList<>(Arrays.asList("Body:", "OK:"));
    
    boolean zodpovezeno = false;
    
    /**
     * Konstruktor
     * @param zadani je zadání otázky
     * @param spravneOdpovedi jsou správné odpovědi na otázku
     * @param body je počet bodů za otázku
     */
    protected Otazka(String zadani, List<String> spravneOdpovedi, int body){
        this.zadani = zadani;
        this.spravneOdpovedi = spravneOdpovedi;
        this.body = body;
    }
    
    // Abstraktní metoda pro spuštění otázky
    protected abstract boolean polozOtazku();
    
    // Abstraktní metoda pro kontrolu odpovědí uživatele
    public abstract boolean kontrolaOdpovedi(List<String> odpoved);
    
    // Abstraktní metoda pro tisk otázky
    protected abstract void tiskni();

    /**
     * Getter pro body
     * @return body
     */
    public int getBody() {
        return body;
    }
    
    /**
     * Getter pro zadání
     * @return zadání
     */
    public String getZadani() {
        return zadani;
    }
    
    /**
     * Getter pro všechny možné odpovědi
     * @return možnosti
     */
    public List<String> getMoznosti() {
        return spravneOdpovedi;
    }
    
    /**
     * Setter pro logickou hodnotu jeSpravne
     * @param jeSpravne 
     */
    public void setJeSpravne(boolean jeSpravne) {
        this.jeSpravne = jeSpravne;
    }
    
    /**
     * Getter pro logickou hodnotu jeSpravne
     * @return jeSpravne
     */
    public boolean isJeSpravne() {
        return jeSpravne;
    }
    
    /**
     * Getter pro logickou hodnotu jeZodpovezeno
     * @return jeZodpovezeno
     */
    public boolean isZodpovezeno() {
        return zodpovezeno;
    }
    
    /**
     * Setter pro logickou hodnotu jeZodpovezeno
     * @param zodpovezeno
     */
    public void setZodpovezeno(boolean zodpovezeno) {
        this.zodpovezeno = zodpovezeno;
    }
    
}
