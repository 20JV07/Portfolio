/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Kurz;

import java.util.List;
import java.util.Scanner;

/**
 * Třída pro uchovávání otázky typu TEXT. Potomek třídy Otazka.
 * @author Jakub Vávra
 */
public class Text extends Otazka {
    
    /**
     * Konstruktor
     * @param zadani je zadání otázky
     * @param spravneOdpovedi jsou správné odpovědi na otázku
     * @param body je počet bodů za otázku 
     */
    public Text(String zadani, List<String> spravneOdpovedi, int body){
        super(zadani, spravneOdpovedi, body); // Volání konstruktoru předka
    }
    
    /**
     * Překrytá metoda pro spuštění otázky
     * @return logickou hodnotu, podle správnosti odpovědi uživatele
     */
    @Override
    protected boolean polozOtazku(){
        System.out.println("Otázka: \n" + zadani);
        
        // Načtení odpovědi uživatele
        System.out.println("Zadej svou odpověď: ");
        Scanner sc = new Scanner(System.in);
        odpovedi.clear();
        odpovedi.add(sc.next().trim().toLowerCase());
        
        // Kontrola odpovědi uživatele
        if(kontrolaOdpovedi(odpovedi)){
            System.out.println("Správná odpověď! Získáno " + body + " bodů.\n");
            return true; // Pokud je odpověď správná
        }else{
            System.out.println("Špatná odpověď! Správná odpověď je " + spravneOdpovedi.get(0) + ".\n");
            return false; // Pokud je odpověď chybná
        }
        
    }
    
    /**
     * Překrytá metoda pro kontrolu odpovědi uživatele
     * @param odpovedi je kolekce s odpovědmi uživatele
     * @return logickou hodnotu, podle správnosti odpovědi uživatele
     */
    @Override
    public boolean kontrolaOdpovedi(List<String> odpovedi){
        return spravneOdpovedi.contains(odpovedi.get(0));
    }
    
    /**
     * Překrytá metoda pro tisk otázky.
     */
    @Override
    public void tiskni(){
        System.out.print("Text: " + zadani);
        System.out.println("Body: " + body);
        System.out.println("OK: " + spravneOdpovedi);
    }
    
    
}
