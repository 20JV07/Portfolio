/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Kurz;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Třída pro uchovávání obsahu tématu.
 * @author Jakub Vávra
 */
public class Tema {
    // Název tématu
    protected String nazev;
    
    // Teoretické informace, vztahující se k tématu
    protected String informace;
    
    // Kolekce s otázkami, které kurz obsahuje
    protected List<Otazka> otazky = new ArrayList<>();
    
    /**
     * Konstruktor 
     * @param nazev je názvem tématu
     */
    public Tema(String nazev){
        this.nazev = nazev;
    }
    
    /**
     * Metoda pro přidání informací
     * @param informace obsahuje informace, které budou přidány
     */
    public void pridatInformace(String informace){
        this.informace = informace;
    }
    
    /**
     * Metoda pro přidání otázky
     * @param otazka je otázka, která bude přidána
     */
    public void pridatOtazku(Otazka otazka){
        otazky.add(otazka);
    }
    
    /**
     * Getter pro název
     * @return název
     */
    public String getNazev() {
        return nazev;
    }
    
    /**
     * Getter pro informace
     * @return informace
     */
    public String getInformace() {
        return informace;
    }
    
    /**
     * Getter pro kolekci otazek
     * @return otazky
     */
    public List<Otazka> getOtazky() {
        return otazky;
    }
    
    /**
     * Metoda pro tisk obsahu celého tématu.
     */
    public void tiskni(){
        System.out.println("Téma: " + nazev);
        System.out.println(informace);
        
        for(Otazka otazka: otazky){
            if(otazka != null){
                otazka.tiskni(); // Otázky se tisknou vlastní metodou
                System.out.println("");
            }
        }
    }
    
    /**
     * Metoda pro spuštění tématu.
     * @return počet získaných bodů
     */
    public int spust(){
        System.out.println("Téma: " + nazev);
        System.out.println(informace);
        boolean chyba = false;
        int body = 0;
        
        List<Otazka> zamichaneOtazky = new ArrayList<>(otazky); // Zamíchání otázek
        Collections.shuffle(zamichaneOtazky);
        for(Otazka otazka: zamichaneOtazky){
            if(otazka != null){
                while(!otazka.polozOtazku()){ // Otázka bude pokládána, dokud ji uživatel správně nezodpoví
                    System.out.println("Odpověz znovu.");
                    chyba = true;
                }
                if(!chyba){
                    body += otazka.getBody();
                    chyba = false;
                }
            }
        }
        
        return body;
    }
    
    
}
    