/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Kurz;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * Třída pro uchovávání otázky typu DOPLŇOVAČKA. Potomek třídy Otazka.
 * @author Jakub Vávra
 */
public class Doplnovacka extends Otazka {
    // Kolekce obsahující špatné odpovědi
    protected List<String> spatneOdpovedi = new ArrayList<>();
    
    /**
     * Konstruktor
     * @param zadani je zadání otázky
     * @param spravneOdpovedi jsou správné odpovědi na otázku
     * @param spatneOdpovedi jsou chybné odpovědi na otázku
     * @param body je počet bodů za otázku
     */
    public Doplnovacka(String zadani, List<String> spravneOdpovedi, List<String> spatneOdpovedi, int body){
        super(zadani, spravneOdpovedi, body);
        this.spatneOdpovedi = spatneOdpovedi;
        klicSlovaOtazka.add("KO:"); // Nové klíčové slovo otázky
    }
    
    /**
     * Getter pro správné i chybné odpovědi
     * @return možnosti
     */
    @Override
    public List<String> getMoznosti(){
        List<String> moznosti = new ArrayList<>(spravneOdpovedi);
        moznosti.addAll(spatneOdpovedi);
        return moznosti;
    }
    
    /**
     * Překrytá metoda pro spuštění otázky
     * @return logickou hodnotu, podle správnosti odpovědi uživatele
     */
    @Override
    protected boolean polozOtazku() {
        System.out.println("Doplňovačka: " + zadani);
        
        // Promíchání kolekce s nabídkou slov k doplnění
        List<String> nabidka = new ArrayList<>(spravneOdpovedi);
        nabidka.addAll(spatneOdpovedi);
        Collections.shuffle(nabidka);
        
        // Načtení odpovědi uživatele
        System.out.println("Vyber správné odpovědi z nabídky. Pokud otázka obsahuje více míst na doplnění, odděl jednotlivé odpovědi čárkou. \nNabídka slov: " + nabidka);
        Scanner sc = new Scanner(System.in);
        String radek = sc.nextLine();
        
        // Zpracování odpovědi uživatele
        odpovedi.clear();
        String[] slova = radek.split(",");
        for(String slovo: slova){
            odpovedi.add(slovo.trim().toLowerCase());
        }
        
        // Kontrola odpovědi uživatele
        if(kontrolaOdpovedi(odpovedi)){
            System.out.println("Správné odpovědi! Získáno " + body + " bodů.\n");
            return true;
        }else{
            System.out.println("Nějaká odpověď je špatně nebo jsi nedoplnil vše! Správné doplnění je: " + spravneOdpovedi + ".\n");
            return false;
        }
    }
    
    /**
     * Překrytá metoda pro kontrolu odpovědi uživatele
     * @param odpovedi je kolekce s odpovědmi uživatele
     * @return logickou hodnotu, podle správnosti odpovědi uživatele
     */
    @Override
    public boolean kontrolaOdpovedi(List<String> odpovedi){
        return odpovedi.containsAll(spravneOdpovedi) && spravneOdpovedi.containsAll(odpovedi);
    }
    
    /**
     * Překrytá metoda pro tisk otázky.
     */
    @Override
    public void tiskni(){
        System.out.print("Doplňovačka: " + zadani);
        System.out.println("Body: " + body);
        System.out.println("OK: " + spravneOdpovedi);
        System.out.println("KO: " + spatneOdpovedi);
    }

    public List<String> getSpatneOdpovedi() {
        return spatneOdpovedi;
    }
    
    
    public List<String> getSpravneOdpovedi() {
        return spravneOdpovedi;
    }
}
