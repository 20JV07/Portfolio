/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Kurz;

import java.util.ArrayList;
import java.util.List;

/**
 * Třída pro uchovávání obsahu kurzu.
 * @author Jakub Vávra
 */
public class Kurz {
    // Název kurzu
    protected String nazev;
    
    // Kolekce s tématy, které kurz obsahuje
    protected List<Tema> temata = new ArrayList<>();
    
    /**
     * Konstruktor
     * @param nazev je názvem kurzu
     */
    public Kurz(String nazev){
        this.nazev = nazev;
    }
    
    /**
     * Metoda pro přidání tématu
     * @param tema je téma, které bude přidáno
     */
    public void pridatTema(Tema tema){
        this.temata.add(tema);
    }
    
    /**
     * Metoda pro tisk obsahu celého kurzu.
     */
    public void tiskni(){
        System.out.println("Kurz: " + nazev);
        
        for(Tema tema: temata){ // Témata se tisknou vlastní metodou
            if(tema != null){
                tema.tiskni();
            }
        }
    }
    
    /**
     * Metoda pro spuštění kurzu.
     */
    public void spust(){
        System.out.println("Kurz: " + nazev);
        int body = 0;
        
        for(Tema tema: temata){ //Témata se spouští vlastní metodou
            if(tema != null){
                body += tema.spust();
            }
        }
        
        System.out.println("Kurz dokončen! Získáno " + body + " bodů.");
    }
    
    /**
     * Getter pro kolekci témat
     * @return témata
     */
    public List<Tema> getTemata(){
        return temata;
    }
    
    /**
     * Getter pro název kurzu
     * @return název
     */
    public String getNazev() {
        return nazev;
    }
    
    
}
