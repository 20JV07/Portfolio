/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Kurz;

import java.util.List;
import java.util.Scanner;

/**
 * Třída pro uchovávání otázky typu PRAVDA/LEŽ. Potomek třídy Otazka.
 * @author Jakub Vávra
 */
public class PravdaLez extends Otazka {
    // Řetězec, obsahující správné znění výroku ze zadání
    private final String spravneTvrzeni;

    /**
     * Konstruktor
     * @param zadani je zadání otázky
     * @param spravneOdpovedi jsou správné odpovědi na otázku
     * @param spravneTvrzeni je správné znění výroku ze zadání
     * @param body je počet bodů za otázku
     */
    public PravdaLez(String zadani, List<String> spravneOdpovedi, String spravneTvrzeni, int body) {
        super(zadani, spravneOdpovedi, body);
        this.spravneTvrzeni = spravneTvrzeni;
        klicSlovaOtazka.add("Tvrzení:"); // Nové klíčové slovo otázky
    }
    
    /**
     * Překrytá metoda pro spuštění otázky
     * @return logickou hodnotu, podle správnosti odpovědi uživatele
     */
    @Override
    protected boolean polozOtazku() {
        System.out.println("Pravda, nebo lež: \n" + zadani);
        
        // Načtení odpovědi uživatele
        System.out.println("Zadej svou odpověď ve formátu \"Pravda\", nebo \"Lež\": ");
        Scanner sc = new Scanner(System.in);
        odpovedi.clear();
        odpovedi.add(sc.next().trim().toLowerCase());
        
        // Kontrola odpovědi uživatele
        if(kontrolaOdpovedi(odpovedi)){
            System.out.println("Správná odpověď! Získáno " + body + " bodů.\n");
            return true; // Pokud je odpověď správná
        }else{
            System.out.println("Špatná odpověď! Správná odpověď je " + spravneOdpovedi.get(0) + ". Správné znění zadaného tvrzení je: " + spravneTvrzeni);
            return false; // Pokud je odpověď chybná
        }
       
    }
    
    /**
     * Překrytá metoda pro kontrolu odpovědi uživatele
     * @param odpovedi je kolekce s odpovědmi uživatele
     * @return logickou hodnotu, podle správnosti odpovědi uživatele
     */
    @Override
    public boolean kontrolaOdpovedi(List<String> odpovedi) {
        return spravneOdpovedi.contains(odpovedi.get(0));
    }
    
    /**
     * Getter pro správné tvrzení
     * @return správné tvrzení
     */
    public String getSpravneTvrzeni() {
        return spravneTvrzeni;
    }
    
    /**
     * Překrytá metoda pro tisk otázky.
     */
    @Override
    protected void tiskni() {
        System.out.print("Pravda/lež: " + zadani);
        System.out.println("Body: " + body);
        System.out.println("OK: " + spravneOdpovedi);
        System.out.println("Správné tvrzení: " + spravneTvrzeni);
    }
    
}
