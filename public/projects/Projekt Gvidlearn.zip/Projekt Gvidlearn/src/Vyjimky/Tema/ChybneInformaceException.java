/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vyjimky.Tema;

/**
 * Vyjímka pro třídu Tema, která indikuje problém s načtením informací o tématu.
 * @author Jakub Vávra
 */
public class ChybneInformaceException extends Exception {
    /**
     * Prázdný konstrutor
     */
    public ChybneInformaceException() {
    }
}
