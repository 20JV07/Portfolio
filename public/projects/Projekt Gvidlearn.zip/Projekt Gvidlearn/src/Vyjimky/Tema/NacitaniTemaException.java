/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vyjimky.Tema;

/**
 * Hlavní vyjímka pro načítání třídy Téma.
 * @author Jakub Vávra
 */
public class NacitaniTemaException extends Exception {
    /**
     * Prázdný konstrutor
     */
    public NacitaniTemaException() {
    }
    
    /**
     * Konstruktor
     * @param zprava je zpráva, kterou bude vyjímka obsahovat
     */
    public NacitaniTemaException(String zprava) {
        super(zprava);
    }
    
    /**
     * Konstruktor
     * @param zprava je zpráva, kterou bude vyjímka obsahovat
     * @param pricina je příčina, kterou bude vyjímka obsahovat
     */
    public NacitaniTemaException(String zprava, Throwable pricina) {
        super(zprava, pricina);
    }
}
