/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vyjimky.Kurz;

/**
 * Hlavní vyjímka pro načítání třídy Kurz.
 * @author Jakub Vávra
 */
public class NacitaniKurzException extends Exception {
    /**
     * Prázdný konstrutor
     */
    public NacitaniKurzException() {
    }
    
    /**
     * Konstruktor
     * @param zprava je zpráva, kterou bude vyjímka obsahovat
     */
    public NacitaniKurzException(String zprava) {
        super(zprava);
    }
    
    /**
     * Konstruktor
     * @param zprava je zpráva, kterou bude vyjímka obsahovat
     * @param pricina je příčina, kterou bude vyjímka obsahovat
     */
    public NacitaniKurzException(String zprava, Throwable pricina) {
        super(zprava, pricina);
    }
}
