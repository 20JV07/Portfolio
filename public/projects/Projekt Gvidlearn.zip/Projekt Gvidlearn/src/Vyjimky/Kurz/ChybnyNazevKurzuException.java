/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vyjimky.Kurz;

/**
 * Vyjímka pro třídu Kurz, která indikuje problém s načtením názvu.
 * @author Jakub Vávra
 */
public class ChybnyNazevKurzuException extends Exception {
    /**
     * Prázdný konstruktor
     */
    public ChybnyNazevKurzuException() {
    }
    
}
