/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package Vyjimky.Otazka;

/**
 * Vyjímka pro třídu Otazka, která indikuje problém s načtením správného znění zadaného výroku u otázek typu PRAVDA/LEŽ.
 * @author Jakub Vávra
 */
public class ChybneTvrzeniException extends Exception {
    /**
     * Prázdný konstruktor
     */
    public ChybneTvrzeniException() {
    }
}
