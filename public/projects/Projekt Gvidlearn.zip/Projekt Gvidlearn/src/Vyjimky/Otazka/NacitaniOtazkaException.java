/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package Vyjimky.Otazka;

/**
 * Hlavní vyjímka pro načítání třídy Otazka.
 * @author Jakub Vávra
 */
public class NacitaniOtazkaException extends Exception {
    /**
     * Prázdný konstrutor
     */
    public NacitaniOtazkaException(){
    }
    
    /**
     * Konstruktor
     * @param zprava je zpráva, kterou bude vyjímka obsahovat
     */
    public NacitaniOtazkaException(String zprava) {
        super(zprava);
    }
    
    /**
     * Konstruktor
     * @param zprava je zpráva, kterou bude vyjímka obsahovat
     * @param pricina je příčina, kterou bude vyjímka obsahovat
     */
    public NacitaniOtazkaException(String zprava, Throwable pricina){
        super(zprava, pricina);
    }
}
