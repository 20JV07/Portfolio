/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vyjimky.Otazka;

/**
 * Vyjímka pro třídu Otazka, která indikuje problém s načtením správných odpovědí.
 * @author Jakub Vávra
 */
public class ChybneSpravneOdpovediException extends Exception{
    /**
     * Prázdný konstruktor
     */
    public ChybneSpravneOdpovediException() {   
    }
}
