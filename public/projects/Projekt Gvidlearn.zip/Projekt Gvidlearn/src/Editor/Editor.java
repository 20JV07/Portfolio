/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Editor;

import EditorGUI.GUIInterface;
import EditorGUI.NovyDoplnovackaPanel;
import EditorGUI.NovyKurzPanel;
import EditorGUI.NovyPravdaLezPanel;
import EditorGUI.NovyTemaPanel;
import EditorGUI.NovyTextPanel;
import static EditorGUI.Tovarna.ZpracujPanelFactory.create;
import static EditorGUI.Tovarna.ZpracujPanelFactory.registerZpracujPanel;
import Vyjimky.Kurz.NacitaniKurzException;
import Vyjimky.Otazka.NacitaniOtazkaException;
import Vyjimky.Tema.NacitaniTemaException;
import ZpracovaniSouboru.KurzReader;
import ZpracovaniSouboru.Soubor;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 * Třída pro zápis nového a upraveného kurzu do souboru
 *
 * @author Jakub Vávra
 */
public class Editor {

    // StringBuilder obsahující kurz ve správném formátu
    private final StringBuilder obsah = new StringBuilder();

    // Název nového kurzu
    private String nazev;

    // Maximální délka řádku v novém souboru
    private final int maxDelkaRadku = 150;
    
    // Soubor pro získání seznamu kurzů
    Soubor soubor = new Soubor();

    /**
     * Prázdný konstruktor
     */
    public Editor() {
    }

    /**
     * Metoda pro vytvoření hlavičky nového kurzu
     *
     * @param nazev je název kurzu
     * @param puvodniNazev
     * @return úspěch operace
     * @throws Vyjimky.Kurz.NacitaniKurzException
     * @throws java.io.IOException
     */
    public boolean vytvorNovyKurz(String nazev, String puvodniNazev) throws NacitaniKurzException, IOException {
        //Kontrola, jestli název neobsahuje mezery
        if(nazev.trim().contains(" ")){
            throw new NacitaniKurzException("Název kurzu nesmí obsahovat mezery!");
        }
        
        // Načtení seznamu kurzů
        String[] pole;
        try {
            DefaultListModel nazvy = soubor.nactiSeznamKurzu();
            pole = new String[nazvy.size()];
            for (int i = 0; i < nazvy.size(); i++) {
                pole[i] = (String) nazvy.getElementAt(i);
            }
        } catch (IOException e) {
            throw e;
        }
        
        // Kontrola, jestli není název kurzu duplicitní
        if(!nazev.equals(puvodniNazev) && Arrays.asList(pole).contains(nazev)){
            throw new NacitaniKurzException("Kurz s takovým názvem již existuje!");
        }
        
        if (!nazev.isBlank()) { // Pokud není název prázdný
            obsah.append("Kurz:").append(nazev).append("\n");
            this.nazev = nazev;
            return true;
        }
        return false;
    }

    /**
     * Metoda pro přidání nového tématu
     *
     * @param nazev je název tématu
     * @param informace jsou informace o tématu
     * @return úspěch operace
     */
    public boolean pridejTema(String nazev, String informace) {
        if (!nazev.isBlank() && !informace.isBlank()) { // Pokud jsou zadaná data validní
            obsah.append("Téma:").append(nazev).append("\n");

            if (informace.length() > maxDelkaRadku) { // Zarovnání
                informace = zarovnejText(informace, maxDelkaRadku);
            }
            obsah.append(informace).append("\n").append("\n");

            obsah.append("Test:").append("\n");
            return true;
        }
        return false;
    }

    /**
     * Metoda pro přidání nové otázky typu TEXT
     *
     * @param zadani je zadání otázky
     * @param spravnaOdpoved je správná odpověď na otázku
     * @param body jsou body za otázku
     * @return úspěch operace
     */
    public boolean pridejText(String zadani, String spravnaOdpoved, int body) {
        if (!zadani.isBlank() && !spravnaOdpoved.isBlank() && body > 0) { // Pokud jsou zadaná data validní
            if (zadani.length() > maxDelkaRadku) { // Zarovnání
                zadani = zarovnejText(zadani, maxDelkaRadku);
            }
            obsah.append("Text:").append(zadani).append("\n");

            obsah.append("Body:").append(body).append("\n");

            if (spravnaOdpoved.length() > maxDelkaRadku) { // Zarovnání
                spravnaOdpoved = zarovnejText(spravnaOdpoved, maxDelkaRadku);
            }
            obsah.append("OK:").append(spravnaOdpoved.toLowerCase()).append("\n");

            obsah.append("\n");
            return true;
        }
        return false;
    }

    /**
     * Metoda pro přidání nové otázky typu DOPLŇOVAČKA
     *
     * @param zadani je zadání otázky
     * @param spravneOdpovedi je kolekce správných odpovědí na otázku
     * @param spatneOdpovedi je kolekce chybných odpovědí na otázku
     * @param body jsou body za otázku
     * @return úspěch operace
     */
    public boolean pridejDoplnovacka(String zadani, List<String> spravneOdpovedi, List<String> spatneOdpovedi, int body) {
        if (!zadani.isBlank() && !spravneOdpovedi.isEmpty() && !spatneOdpovedi.isEmpty() && body > 0) { // Pokud jsou zadaná data validní
            if (zadani.length() > maxDelkaRadku) { // Zarovnání
                zadani = zarovnejText(zadani, maxDelkaRadku);
            }
            obsah.append("Doplňovačka:").append(zadani).append("\n");

            obsah.append("Body:").append(body).append("\n");

            obsah.append("OK:").append(spravneOdpovedi.toString().toLowerCase().replace("[", "").replace("]", "").replace(", ", ",")).append("\n");

            obsah.append("KO:").append(spatneOdpovedi.toString().toLowerCase().replace("[", "").replace("]", "").replace(", ", ",")).append("\n");

            obsah.append("\n");
            return true;
        }
        return false;
    }

    /**
     * Metoda pro přidání nové otázky typu PRAVDA/LEŽ
     *
     * @param zadani je zadání otázky
     * @param spravnaOdpoved je správná odpověď na otázku
     * @param spravneTvrzeni je správná verze tvrzení ze zadání
     * @param body jsou body za otázku
     * @return úspěch operace
     */
    public boolean pridejPravdaLez(String zadani, String spravnaOdpoved, String spravneTvrzeni, int body) {
        if (!zadani.isBlank() && !spravnaOdpoved.isBlank() && !spravneTvrzeni.isBlank() && body > 0) { // Pokud jsou zadaná data validní
            if (zadani.length() > maxDelkaRadku) { // Zarovnání
                zadani = zarovnejText(zadani, maxDelkaRadku);
            }
            obsah.append("PravdaLež:").append(zadani).append("\n");

            obsah.append("Body:").append(body).append("\n");

            if (spravnaOdpoved.length() > maxDelkaRadku) { // Zarovnání
                spravnaOdpoved = zarovnejText(spravnaOdpoved, maxDelkaRadku);
            }
            obsah.append("OK:").append(spravnaOdpoved).append("\n");

            if (spravneTvrzeni.length() > maxDelkaRadku) { // Zarovnání
                spravneTvrzeni = zarovnejText(spravneTvrzeni, maxDelkaRadku);
            }
            obsah.append("Tvrzení:").append(spravneTvrzeni).append("\n");

            obsah.append("\n");
            return true;
        }
        return false;
    }
    
    /**
     * Registrace pro obsah továrny, která slouží pro převod obsahu panelu do textu v editoru
     */
    private void registrujPanely() {
        registerZpracujPanel(NovyTextPanel.class, (GUIInterface panel) -> { // TEXT
            NovyTextPanel textPanel = (NovyTextPanel) panel;
            return pridejText(textPanel.getZadani().replace("\n", ""), textPanel.getOdpoved(), textPanel.getBody());
        });

        registerZpracujPanel(NovyDoplnovackaPanel.class, (GUIInterface panel) -> { //DOPLŇOVAČKA
            NovyDoplnovackaPanel doplnovackaPanel = (NovyDoplnovackaPanel) panel;
            return pridejDoplnovacka(doplnovackaPanel.getZadani().replace("\n", ""), new ArrayList<>(Arrays.asList(doplnovackaPanel.getSpravneOdpovedi().split(","))), new ArrayList<>(Arrays.asList(doplnovackaPanel.getSpatneOdpovedi().split(","))), doplnovackaPanel.getBody());
        });

        registerZpracujPanel(NovyPravdaLezPanel.class, (GUIInterface panel) -> { // PRAVDA/LEŽ
            NovyPravdaLezPanel pravdaLezPanel = (NovyPravdaLezPanel) panel;
            return pridejPravdaLez(pravdaLezPanel.getZadani().replace("\n", ""), pravdaLezPanel.getOdpoved(), pravdaLezPanel.getTvrzeni().replace("\n", ""), pravdaLezPanel.getBody());
        });
    }

    /**
     * Metoda pro validaci nového kurzu, program se pokusí načíst nový kurz
     * @param puvodniNazev původní název kurzu, slouží pro kontrolu duplicity
     * @param panely panely, ze který jsou převedena data do textu v editoru
     * @return úspěch operace
     * @throws java.io.IOException
     * @throws Vyjimky.Kurz.NacitaniKurzException
     * @throws Vyjimky.Tema.NacitaniTemaException
     * @throws Vyjimky.Otazka.NacitaniOtazkaException
     */
    public boolean validovatKurz(List<GUIInterface> panely, String puvodniNazev) throws IOException, NacitaniKurzException, NacitaniTemaException, NacitaniOtazkaException {
        NovyKurzPanel kurzPanel = (NovyKurzPanel) panely.get(0);
        vynulujObsah();
        
        // Zpracování panelu s kurzem
        if (!vytvorNovyKurz(kurzPanel.getNazev(), puvodniNazev)) {
            JOptionPane.showMessageDialog(null, "Zkontrolujte položky u panelu s kurzem.", "Error!", JOptionPane.ERROR_MESSAGE);
            vynulujObsah();
            return false;
        }

        registrujPanely();
        GUIInterface panel;
        
        // Zpracování ostatních panelů
        for (int i = 1; i < panely.size(); i++) {
            panel = panely.get(i);
            // Zpracování témat
            if (panel instanceof NovyTemaPanel temaPanel) {
                if (!pridejTema(temaPanel.getNazev(), temaPanel.getInformace())) {
                    JOptionPane.showMessageDialog(null, "Zkontrolujte položky u panelů s tématy.", "Error!", JOptionPane.ERROR_MESSAGE);
                    vynulujObsah();
                    return false;
                }
            // Zpracování otázek
            } else {
                if (!create(panel)) { // Továrna
                    JOptionPane.showMessageDialog(null, "Zkontrolujte položky u panelů s otázkami.", "Error!", JOptionPane.ERROR_MESSAGE);
                    vynulujObsah();
                    return false;
                }
            }
        }
        
        // POkus o načtení upraveného kurzu
        BufferedReader br = new BufferedReader(new StringReader(obsah.toString())); // Vstupem je string s obsahem
        KurzReader kurzReader = new KurzReader(br);
        try {
            kurzReader.nactiKurz();
        } catch (IOException | NacitaniKurzException | NacitaniTemaException | NacitaniOtazkaException e) {
            throw e;
        }
        return true;
    }

    /**
     * Metoda pro validaci nového kurzu, program se pokusí načíst nový kurz
     *
     * @return úspěch operace
     * @throws java.io.IOException
     * @throws Vyjimky.Kurz.NacitaniKurzException
     * @throws Vyjimky.Tema.NacitaniTemaException
     * @throws Vyjimky.Otazka.NacitaniOtazkaException
     */
    public boolean validovatKurz() throws IOException, NacitaniKurzException, NacitaniTemaException, NacitaniOtazkaException{
        BufferedReader br = new BufferedReader(new StringReader(obsah.toString())); // Vstupem je string s obsahem
        KurzReader kurzReader = new KurzReader(br);
        try {
            kurzReader.nactiKurz();
        } catch (IOException | NacitaniKurzException | NacitaniTemaException | NacitaniOtazkaException e) {
            throw e;
        }
        return true;
    }

    /**
     * Metoda pro vytvoření souboru s kurzem
     *
     * @return úspěch operace
     */
    public boolean ulozitNovyKurz() {
        try (FileWriter wr = new FileWriter(nazev + ".txt")) {
            wr.write(obsah.toString());
        } catch (IOException e) {
            return false;
        }

        try (FileWriter wr = new FileWriter("Kurzy.txt", true)) { // Přidání nového kurzu do seznamu kurzů
            wr.write("\n" + nazev + ".txt" + " | " + nazev);
        } catch (IOException ex) {
            return false;
        }
        return true;
    }
    
    /**
     * Metoda pro uložení nového obsahu existujícího kurzu
     * @param nazev je název kurzu 
     * @return úspěch operace
     */
    public boolean ulozitStavajiciKurz(String nazev) {
        // Načtení seznamu kurzů
        try {
            soubor.nactiSeznamKurzu();
        } catch (IOException ex) {
            return false;
        }
        
        // Přepsání obsahu souboru s kurzem
        try (FileWriter wr = new FileWriter(soubor.getCesta(nazev))) {
            wr.write(obsah.toString());
        } catch (IOException e) {
            return false;
        }
        
        // Přepsání změny názvu v souboru s kurzem
        try {
            String obsahSouboru = new String(Files.readAllBytes(Paths.get("Kurzy.txt")));
            String novyObsah = obsahSouboru.replaceAll("\\b" + Pattern.quote(nazev) + "\\b", obsah.toString().substring(5, obsah.toString().indexOf("\n")));
            Files.write(Paths.get("Kurzy.txt"), novyObsah.getBytes());
        } catch (IOException ex) {
            return false;
        }
        
        // Výměna souboru v kolekci souborů
        String stary = soubor.getCesta(nazev);
        soubor.vymena(nazev, obsah.toString().substring(5, obsah.toString().indexOf("\n")));
        
        // Přepsání názvu souboru s kurzem
        try {
            Files.move(Paths.get(stary), Paths.get(obsah.toString().substring(5, obsah.toString().indexOf("\n")) + ".txt"), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {}
        
        return true;
    }

    /**
     * Metoda vynuluje obsah editoru
     */
    public void vynulujObsah() {
        obsah.setLength(0);
    }

    /**
     * Metoda pro zarovnání textu
     *
     * @param text je text k zarovnání
     * @param maxDelkaRadku je maximální délka řádku
     * @return zarovnaný text
     */
    private static String zarovnejText(String text, int maxDelkaRadku) {
        StringBuilder vysledek = new StringBuilder();
        String[] slova = text.split(" ");
        int delkaAktualnihoRadku = 0;

        String slovo;
        vysledek.append(slova[0]);
        for (int i = 1; i < slova.length; i++) {
            slovo = slova[i];

            if (delkaAktualnihoRadku + slovo.length() > maxDelkaRadku) {
                vysledek.append("\n");
                delkaAktualnihoRadku = 0;
            } else {
                vysledek.append(" ");
                delkaAktualnihoRadku++;
            }

            vysledek.append(slovo);
            delkaAktualnihoRadku += slovo.length();
        }

        return vysledek.toString();
    }
}
