/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KurzGUI;

/**
 * Třída pro ukládání výsledků testů
 * @author Jakub Vávra
 */
public class Vysledek {
    // Počet zodpovězených otázek
    private int pocetOtazek = 0;
    
    // Počet otázek, za které uživatel dostal body
    private int pocetSpravnych = 0;
    
    // Počet bodů, získaný uživatelem
    private int body = 0;
    
    // Počet bodů, které šlo maximálně získat
    private int bodyMax = 0;
    
    /**
     * Bezparametrický konstruktor
     */
    public Vysledek() {
    }
    
    /**
     * Konstruktor s parametry
     * @param pocetOtazek
     * @param pocetSpravnych
     * @param body
     * @param bodyMax 
     */
    public Vysledek(int pocetOtazek, int pocetSpravnych, int body, int bodyMax) {
        this.pocetOtazek = pocetOtazek;
        this.pocetSpravnych = pocetSpravnych;
        this.body = body;
        this.bodyMax = bodyMax;
    }
    
    /**
     * Getter pro pocetOtazek
     * @return pocetOtazek
     */
    public int getPocetOtazek() {
        return pocetOtazek;
    }
    
    /**
     * Setter pro pocetOtazek
     * @param pocetOtazek 
     */
    public void setPocetOtazek(int pocetOtazek) {
        this.pocetOtazek = pocetOtazek;
    }
    
    /**
     * Getter pro pocetSpravnych
     * @return pocetSpravnych
     */
    public int getPocetSpravnych() {
        return pocetSpravnych;
    }
    
    /**
     * Setter pro pocetSpravnych
     * @param pocetSpravnych 
     */
    public void setPocetSpravnych(int pocetSpravnych) {
        this.pocetSpravnych = pocetSpravnych;
    }
    
    /**
     * Getter pro body
     * @return body
     */
    public int getBody() {
        return body;
    }
    
    /**
     * Setter pro body
     * @param body 
     */
    public void setBody(int body) {
        this.body = body;
    }
    
    /**
     * Getter pro bodyMax
     * @return bodyMax
     */
    public int getBodyMax() {
        return bodyMax;
    }
    
    /**
     * Setter pro bodyMax
     * @param bodyMax 
     */
    public void setBodyMax(int bodyMax) {
        this.bodyMax = bodyMax;
    }
    
    /**
     * Metoda pro vynulování hodnot objektu
     */
    public void vynuluj(){
        this.pocetOtazek = 0;
        this.pocetSpravnych = 0;
        this.body = 0;
        this.bodyMax = 0;
    }
    
}
