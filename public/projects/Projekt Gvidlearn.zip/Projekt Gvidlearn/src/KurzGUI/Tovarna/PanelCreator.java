/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package KurzGUI.Tovarna;

import Kurz.Otazka;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * Rozhraní pro třídy vytvářející panely otázek
 * @author Jakub Vávra
 */
public interface PanelCreator {
    // Metoda pro vytvoření panelu s odpovídajícími parametry
    public JPanel vytvorPanel(Otazka otazka, JButton dalsi);
    
}
