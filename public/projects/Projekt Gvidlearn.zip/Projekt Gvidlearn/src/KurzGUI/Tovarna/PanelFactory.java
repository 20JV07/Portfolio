/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KurzGUI.Tovarna;

import Kurz.Otazka;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * Tovární třída pro vytváření panelů s otázkami
 * @author Jakub Vávra
 */
public class PanelFactory {
    // Kolekce pro ukládání dvojic hodnot <potomek třídy Otazka> a <odpovídající třída pro výrobu panelů>
    private static final Map<Class<? extends Otazka>, PanelCreator> mapa = new HashMap<>();
    
    /**
     * Metoda pro uložení dvojice hodnot do kolekce
     * @param otazka je potomek třídy Otazka
     * @param panelCreator je objekt pro vytvoření panelu
     */
    public static void registerPanelCreator(Class<? extends Otazka> otazka, PanelCreator panelCreator){
        mapa.put(otazka, panelCreator);
    }
    
    /**
     * Metoda pro výběr odpovídajícího objektu pro vytváření panelů a vytvoření panelu
     * @param otazka je otázka, na základě které bude panel vytvořen
     * @param dalsi je tlačítko pro posun otázky
     * @return vytvořený panel
     */
    public static JPanel create(Otazka otazka, JButton dalsi){
        PanelCreator panelCreator = mapa.get(otazka.getClass());
        
        if(panelCreator == null){ // Pokud nebyla v kolekci nalezena odpovídající hodnota
            return null;
        }
        
        return panelCreator.vytvorPanel(otazka, dalsi);
    }
}
