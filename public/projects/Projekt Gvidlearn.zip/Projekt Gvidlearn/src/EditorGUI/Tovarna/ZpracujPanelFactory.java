/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EditorGUI.Tovarna;

import EditorGUI.GUIInterface;
import java.util.HashMap;
import java.util.Map;

/**
 * Tovární třída pro vytváření dat z panelů
 * @author Jakub Vávra
 */
public class ZpracujPanelFactory {
    // Kolekce pro ukládání dvojic hodnot <potomek implementující GUIInterface> a <odpovídající třída pro výrobu panelů>
    private static final Map<Class<? extends GUIInterface>, ZpracujPanel> mapa = new HashMap<>();
    
    /**
     * Metoda pro uložení dvojice hodnot do kolekce
     * @param panel
     * @param zpracuj
     */
    public static void registerZpracujPanel(Class<? extends GUIInterface> panel, ZpracujPanel zpracuj){
        mapa.put(panel, zpracuj);
    }
    
    /**
     * Metoda pro výběr odpovídajícího objektu pro zpracování panelu
     * @param panel
     * @return úspěch operace
     */
    public static boolean create(GUIInterface panel){
        ZpracujPanel zpracuj = mapa.get(panel.getClass());
        if(zpracuj == null){ // Pokud nebyla v kolekci nalezena odpovídající hodnota
            return false;
        }
        
        return zpracuj.zpracujPanel(panel);
    }
}
