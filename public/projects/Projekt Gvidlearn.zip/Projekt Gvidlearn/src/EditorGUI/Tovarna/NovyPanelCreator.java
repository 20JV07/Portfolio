/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EditorGUI.Tovarna;

import Editor.Editor;
import javax.swing.JButton;
import EditorGUI.GUIInterface;

/**
 * Rozhraní pro třídy, které umožňují převod dat kurzu do panelu
 * @author Jakub Vávra
 */
public interface NovyPanelCreator {
    // Metoda vytvářející panel
    public GUIInterface vytvorNovyPanel(Editor editor, JButton dalsi);
}
