/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EditorGUI.Tovarna;

import EditorGUI.GUIInterface;

/**
 * Rozhraní pro třídy umožňující převod dat z panelů do tříd kurzu
 * @author Jakub Vávra
 */
public interface ZpracujPanel {
    // Metoda, zpracovávající panely
    public boolean zpracujPanel(GUIInterface panel);
    
}
