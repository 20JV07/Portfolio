/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EditorGUI.Tovarna;

import Editor.Editor;
import Kurz.Otazka;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import EditorGUI.GUIInterface;

/**
 * Tovární třída pro vytváření panelů s otázkami z dat
 * @author Jakub Vávra
 */
public class NovyPanelFactory {
    // Kolekce pro ukládání dvojic hodnot <potomek třídy Otazka> a <odpovídající třída pro výrobu panelů>
    private static final Map<Class<? extends Otazka>, NovyPanelCreator> mapa = new HashMap<>();
    
    /**
     * Metoda pro uložení dvojice hodnot do kolekce
     * @param otazka je potomek třídy Otazka
     * @param panelCreator je objekt pro vytvoření panelu
     */
    public static void registerPanelCreator(Class<? extends Otazka> otazka, NovyPanelCreator panelCreator){
        mapa.put(otazka, panelCreator);
    }
    
    /**
     * Metoda pro výběr odpovídajícího objektu pro vytváření panelů a vytvoření panelu
     * @param otazka je otázka, na základě které bude panel vytvořen
     * @param editor
     * @param dalsi je tlačítko pro posun otázky
     * @return vytvořený panel
     */
    public static GUIInterface create(Otazka otazka, Editor editor, JButton dalsi){
        NovyPanelCreator panelCreator = mapa.get(otazka.getClass());
        
        if(panelCreator == null){ // Pokud nebyla v kolekci nalezena odpovídající hodnota
            return null;
        }
        
        return panelCreator.vytvorNovyPanel(editor, dalsi);
    }
}
