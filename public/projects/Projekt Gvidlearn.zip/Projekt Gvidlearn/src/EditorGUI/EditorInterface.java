/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EditorGUI;

/**
 * Rozhraní pro panely, které umožňují editování otázek
 * - kvůli implementaci metod v rozhodovacím panelu
 * @author Jakub Vávra
 */
public interface EditorInterface {
    // Metoda pro uložení kurzu
    public void ulozitKurz();
    
    // Metoda pro vytvoření nového tématu
    public void noveTema();
    
    // Metoda pro vytvoření otázky typu PRAVDA/LEŽ
    public void novaPravdaLez();
    
    // Metoda pro vytvoření otázky typu DOPLŇOVAČKA
    public void novaDoplnovacka();
   
    // Metoda pro vytvoření otázky typu TEXT
    public void novyText();
    
}
