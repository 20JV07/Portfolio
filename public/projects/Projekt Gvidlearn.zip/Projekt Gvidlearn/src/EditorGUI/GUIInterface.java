/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EditorGUI;

/**
 * Rozhraní pro panely editoru
 * @author Jakub Vávra
 * @param <T> je objekt, který panel zobrazuje
 */
public interface GUIInterface<T> {
    
    // Nastavení obsahu komponent podle parametrů objektů
    public void setKomponenty(T object);
    
    // Metoda, pro zjištění, zda byl panel vyplněn
    public boolean jeZodpovezeno();
}
