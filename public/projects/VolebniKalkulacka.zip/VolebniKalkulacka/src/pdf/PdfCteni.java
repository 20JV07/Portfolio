/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

    
import Data.Skola;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.parser.PdfTextExtractor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Třída realizující načítání PDF souboru
 * @author Jakub Vávra
 */
public class PdfCteni {

    public PdfCteni() {
    }
    
    /**
     * Funkce pro načtení škol z pdf podle pořadí voleb
     * @param cesta je cesta k souboru
     * @return načtené školy
     */
    public List<Skola> nactiSkolyZPdf(String cesta)  {
        List<Skola> skoly = new ArrayList<>();
                
        try (PdfReader reader = new PdfReader(cesta)) {
            PdfTextExtractor extractor = new PdfTextExtractor(reader);
            
            // rozdělení souboru na řádky
            String text = extractor.getTextFromPage(1);
            String[] radky = text.split("\\r?\\n");

            StringBuilder buffer = new StringBuilder();

            // zpracování řádků
            for (String radek: radky) {
                radek = radek.trim();
                
                // pokud se nejedná o řádek se školou, pokračuj na další řádek
                if (radek.isEmpty() || radek.contains("Výsledky") || radek.contains("Vygenerováno") || radek.contains("Název")){
                    continue;
                }
                
                radek = radek.replaceFirst("^\\d+\\.\\s*", "");

                // víceřádková škola
                if (radek.matches("\\d+")) {
                    int body = Integer.parseInt(radek);
                    
                    String nazev = buffer.toString().trim();
                    if (!nazev.isEmpty()) {
                        skoly.add(new Skola(body, nazev));
                    }
                    buffer.setLength(0);
                }
                
                // jednořádková škola
                else if (radek.matches(".*\\d+$")) {
                    int lastSpace = radek.lastIndexOf(' ');
                    if (lastSpace > 0) {
                        String nazev = radek.substring(0, lastSpace).trim();
                        int body = Integer.parseInt(radek.substring(lastSpace + 1).trim());
                        skoly.add(new Skola(body, nazev));
                    }
                    buffer.setLength(0);
                }
                
                else{
                    buffer.append(" ");
                    buffer.append(radek);
                }
            }
            
        } catch (IOException e) {
            return null;
        }
        
        if(skoly.isEmpty()){
            return null;
        }
        
        // úprava dat
        for(Skola skola: skoly){
            String nazev = skola.getNazev();
            int indexZavorky = nazev.lastIndexOf('(');
            String nazevNovy = nazev.substring(0, indexZavorky).trim();
            String bodyString = nazev.substring(indexZavorky + 1, nazev.length() - 1);
            
            skola.setNazev(nazevNovy);
            skola.setVolebniCislo(Integer.parseInt(bodyString));
        }
        
        
        return skoly;
    }

    
    
    
}
