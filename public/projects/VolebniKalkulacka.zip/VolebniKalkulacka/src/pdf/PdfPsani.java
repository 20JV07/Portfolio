/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

import Data.Skola;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Třída realizující vytvoření PDF souboru
 * @author Jakub Vávra
 */
public class PdfPsani {

    public PdfPsani() {
    }
    
    /**
     * Funkce pro výpis pořadí podle voleb
     * @param skoly jsou školy k vypsání
     * @param cesta je cesta k souboru
     * @param finalniVysledky přepínač
     * @return
     * @throws FileNotFoundException
     * @throws DocumentException
     * @throws IOException 
     */
    public boolean vypisPoradi(List<Skola> skoly, String cesta, boolean finalniVysledky) throws FileNotFoundException, DocumentException, IOException {
        try (Document vystup = new Document(PageSize.A4, 50, 50, 50, 50)) {
            PdfWriter.getInstance(vystup, new FileOutputStream(cesta));
            vystup.open();

            // nastavení textu hlaviček
            String textNadpisu = finalniVysledky ? "Celkové výsledky" : "Výsledky voleb";
            String textHlavickyBodu = finalniVysledky ? "Skóre" : "Body";

            // nastavení fontů
            BaseFont bf = BaseFont.createFont(
                    getClass().getResource("/dejavu-fonts-ttf-2.37/ttf/DejaVuSans.ttf").toString(),
                    BaseFont.IDENTITY_H,
                    BaseFont.EMBEDDED
            );

            Font titleFont = new Font(Font.HELVETICA, 24, Font.BOLD, new Color(55, 65, 117));
            Font headerFont = new Font(bf, 12, Font.BOLD, Color.BLACK);
            Font regularFont = new Font(bf, 12);
            Font italicFont = new Font(bf, 12, Font.ITALIC);
            Font boldFont = new Font(bf, 12, Font.BOLD);

            // výpis nadpisu
            Paragraph title = new Paragraph(textNadpisu, titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            vystup.add(title);
            vystup.add(new Paragraph(" "));
            vystup.add(new Paragraph(" "));

            // výpis tabulky
            PdfPTable table = new PdfPTable(3);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{0.7f, 8f, 1f});
            table.getDefaultCell().setBorderWidth(0.5f);
            table.getDefaultCell().setPadding(8f);

            String[] hlavicky = {"", "Název školy", textHlavickyBodu};
            for (String text : hlavicky) {
                PdfPCell cell = new PdfPCell(new Phrase(text, headerFont));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setBackgroundColor(new Color(230, 230, 230));
                cell.setBorderWidth(0.5f);
                cell.setPadding(8f);
                table.addCell(cell);
            }

            int index = 1;
            for (Skola skola : skoly) {
                String hodnotaBodu;
                if (finalniVysledky) {
                    hodnotaBodu = String.valueOf(skola.getCelkovePoradi());
                } else {
                    hodnotaBodu = String.valueOf(skola.getBodyVolby());
                }

                table.addCell(createCell(index + ".", regularFont, Element.ALIGN_CENTER));
                table.addCell(createCell(skola.getNazev() + " (" + skola.getVolebniCislo() + ")", italicFont, Element.ALIGN_LEFT));
                table.addCell(createCell(" " + hodnotaBodu, boldFont, Element.ALIGN_CENTER));
                index++;
            }

            vystup.add(table);
            vystup.add(new Paragraph(" "));
            vystup.add(new Paragraph(" "));

            // výpis data a času
            LocalTime cas = LocalTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
            String casString = cas.format(formatter);
            Paragraph subtitle = new Paragraph(
                    "Vygenerováno " + LocalDate.now() + " v " + casString,
                    italicFont
            );
            subtitle.setAlignment(Element.ALIGN_CENTER);
            vystup.add(subtitle);

        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (DocumentException | IOException ex) {
            throw ex;
        }

        return true;
    }
    
    /**
     * Obalující funkce pro výpis pořadí podle voleb
     * @param skoly jsou školy k vypsání
     * @param cesta je cesta souboru
     * @return
     * @throws FileNotFoundException
     * @throws DocumentException
     * @throws IOException 
     */
    public boolean vypisPoradiVoleb(List<Skola> skoly, String cesta) throws FileNotFoundException, DocumentException, IOException {
        return vypisPoradi(skoly, cesta, false);
    }

    /**
     * Obalující funkce pro výpis konečného pořadí
     * @param skoly jsou školy k vypsání
     * @param cesta je cesta souboru
     * @return
     * @throws FileNotFoundException
     * @throws DocumentException
     * @throws IOException 
     */
    public boolean vypisPoradiFinal(List<Skola> skoly, String cesta) throws FileNotFoundException, DocumentException, IOException {
        return vypisPoradi(skoly, cesta, true);
    }

    /**
     * Pomocná funkce pro vytvoření buňky tabulky
     * @param text je text buňky
     * @param font je použity font
     * @param alignment je odsazení
     * @return vytvořenou buňku
     */
    private PdfPCell createCell(String text, Font font, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBorderWidth(0.5f);
        cell.setPadding(8f);
        cell.setHorizontalAlignment(alignment);
        return cell;
    }

}
