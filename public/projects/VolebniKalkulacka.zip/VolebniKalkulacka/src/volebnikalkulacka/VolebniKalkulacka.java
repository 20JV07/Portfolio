/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package volebnikalkulacka;


import Data.Skola;
import GUI.MainFrame;
import GUI.MenuPanel;
import GUI.PocitadloPanel;
import GUI.ScitackaPanel;
import GUI.UdajeKomisePanel;
import GUI.UdajeVolbyPanel;
import GUI.VysledekVolbyPanel;
import GUI.VysledekFinalPanel;
import GUI.VysledekKomisePanel;
import java.util.List;
import java.util.ArrayList;

/**
 * Hlavní třída projektu
 * @author Jakub Vávra
 */
public class VolebniKalkulacka {
    
    // Hlavní frame, kde se vykresluje GUI
    private static final MainFrame frame = new MainFrame();
    
    // Kolekce škol, během programu je kolekce aktualizována, jak uživatel zadává data
    private static List<Skola> skoly = new ArrayList<>();
  
    /**
     * Vykreslí uvodní obrazovku
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frame.setVisible(true);
        zobrazMenu();
    }
    
    /**
     * Funkce zobrazí úvodní menu
     */
    public static void zobrazMenu(){
        MenuPanel menu = new MenuPanel();
        MainFrame.zmenPanel(menu);
    }
    
    /**
     * Funkce zobrazí dialog pro zadávání údajů o volbách
     */
    public static void zadaniDatVolby(){
        UdajeVolbyPanel udaje = new UdajeVolbyPanel();
        MainFrame.zmenPanel(udaje);
    }
    
    /**
     * Funkce aktualizuje kolekci škol a zobrazí dialog pro počítání hlasů
     * @param skoly je nová kolekce škol
     */
    public static void ulozeniDatVolby(List<Skola> skoly){
        VolebniKalkulacka.skoly = skoly;
        PocitadloPanel pocitadloPanel = new PocitadloPanel(VolebniKalkulacka.skoly);
        MainFrame.zmenPanel(pocitadloPanel);
    }
    
    /**
     * Funkce zobrazí seznam škol v pořadí podle výsledků voleb
     * @param skoly jsou školy k zobrazení
     */
    public static void zobrazVysledekVolby(List<Skola> skoly){
        VolebniKalkulacka.skoly = skoly;
        VysledekVolbyPanel vysledekPanel = new VysledekVolbyPanel(VolebniKalkulacka.skoly);
        MainFrame.zmenPanel(vysledekPanel);
    }
    
    /**
     * Funkce zobrazí dialog pro zadávání údajů o komisi
     */
    public static void zadaniDatKomise() {
        UdajeKomisePanel udaje = new UdajeKomisePanel();
        MainFrame.zmenPanel(udaje);
    }
    
    /**
     * Funkce zobrazí dialog pro zadání hodnocení komise
     * @param pocetClenu je počet členů komise
     */
    public static void ulozeniDatKomise(int pocetClenu) {
        ScitackaPanel scitacka = new ScitackaPanel(skoly, pocetClenu);
        MainFrame.zmenPanel(scitacka);
    }
    
    /**
     * Funkce zobrazí seznam škol v pořadí podle hodnocení komise
     * @param skoly jsou školy k zobrazení
     */
    public static void zobrazVysledekKomise(List<Skola> skoly){
        VolebniKalkulacka.skoly = skoly;
        VysledekKomisePanel vysledekPanel = new VysledekKomisePanel(VolebniKalkulacka.skoly);
        MainFrame.zmenPanel(vysledekPanel);
    }
    
    /**
     * Funkce zobrazí seznam škol v pořadí podle celkových výsledků
     * @param skoly jsou školy k zobrazení
     */
    public static void zobrazVysledekFinal(List<Skola> skoly){
        VolebniKalkulacka.skoly = skoly;
        VysledekFinalPanel vysledekPanel = new VysledekFinalPanel(VolebniKalkulacka.skoly);
        MainFrame.zmenPanel(vysledekPanel);
    }
}
