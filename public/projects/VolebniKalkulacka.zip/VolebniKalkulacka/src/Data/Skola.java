/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

/**
 * Datová třída reprezentující jeden soutěžící tým/školu
 * @author Jakub Vávra
 */
public class Skola {
    
    // název školy
    private String nazev;
    
    // získané body ve volbách
    private int bodyVolby = 0;
    
    // získané body od komise
    private int bodyKomise = 0;
    
    // pořadí ve volbách
    private int poradiVolby = 0;
    
    // pořadí podle hodnocní komise
    private int poradiKomise = 0;
    
    // volební číslo
    private int volebniCislo;
    
    /**
     * Konstruktor
     * @param nazev je název školy
     * @param volebniCislo je volební číslo
     */
    public Skola(String nazev, int volebniCislo){
        this.nazev = nazev;
        this.volebniCislo = volebniCislo;
    }
    
    /**
     * Konstruktor
     * @param bodyVolby jsou body získané ve volbách
     * @param nazev je název školy
     */
    public Skola(int bodyVolby, String nazev){
        this.nazev = nazev;
        this.bodyVolby = bodyVolby;
    }
    
    /**
     * Getter název
     * @return název školy 
     */
    public String getNazev() {
        return nazev;
    }
    
    /**
     * Getter volebniCislo
     * @return volební číslo
     */
    public int getVolebniCislo() {
        return volebniCislo;
    }
    
    /**
     * Getter bodyVolby
     * @return body získané ve volbách
     */
    public int getBodyVolby() {
        return bodyVolby;
    }
    
    /**
     * Getter bodyKomise
     * @return body získané z hodnocení komise
     */
    public int getBodyKomise() {
        return bodyKomise;
    }
    
    /**
     * Getter poradiVolby
     * @return pořadí ve volbách
     */
    public int getPoradiVolby() {
        return poradiVolby;
    }

    /**
     * Getter poradiKomise
     * @return pořadí podle komise
     */
    public int getPoradiKomise() {
        return poradiKomise;
    }
    
    /**
     * Funkce spočítá celkové pořadí
     * @return vypočítané celkové pořadí
     */
    public double getCelkovePoradi() {
        return (poradiKomise+poradiVolby)/2.0;
    }

    /**
     * Setter poradiVolby
     * @param poradiVolby 
     */
    public void setPoradiVolby(int poradiVolby) {
        this.poradiVolby = poradiVolby;
    }

    /**
     * Setter nazev
     * @param nazev 
     */
    public void setNazev(String nazev) {
        this.nazev = nazev;
    }

    /**
     * Setter bodyVolby
     * @param bodyVolby 
     */
    public void setBodyVolby(int bodyVolby) {
        this.bodyVolby = bodyVolby;
    }

    /**
     * Setter volebniCilo
     * @param volebniCislo 
     */
    public void setVolebniCislo(int volebniCislo) {
        this.volebniCislo = volebniCislo;
    }

    /**
     * Setter bodyKomise
     * @param bodyKomise 
     */
    public void setBodyKomise(int bodyKomise) {
        this.bodyKomise = bodyKomise;
    }
    
    /**
     * Setter poradiKomise
     * @param poradiKomise 
     */
    public void setPoradiKomise(int poradiKomise) {
        this.poradiKomise = poradiKomise;
    }
}
