/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;


import com.formdev.flatlaf.extras.FlatSVGIcon;
import javax.swing.JLabel;

/**
 * Třída pro vykreslení SVG obrázků
 * @author Jakub Vávra
 */
public class Logo extends JLabel {
    
    // obrázek k vykreslení
    private FlatSVGIcon logo;
    
    /**
     * Funkce vykreslí obrázek
     * @param obrazek je cesta k obrázku
     * @param sirka je šířka obrázku
     * @param vyska je výška obrázku
     */
    public void vykresliLogo(String obrazek, int sirka, int vyska){
        logo = new FlatSVGIcon(obrazek, sirka, vyska);
        this.setIcon(logo);
    }
    
}
